#
# Copyright (c) 2008 by Conselleria de Infraestructuras y Transporte de la
# Generalidad Valenciana 
#
# Authors: 
# Conselleria de Infraestructuras y Transporte de la Generalidad Valenciana (Spain) 
# Model Driven Development sl  Valencia (Spain) www.ModelDD.org 
# Antonio Carrasco Valero                       carrasco@ModelDD.org
#
# Licensed under GPL
#



Copy this folder into your Plone Products folder.
This is usually located inside the Plone installation, folder /Data/Products).


